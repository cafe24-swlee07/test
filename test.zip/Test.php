<?php

$aArr = [
    'test' => [1]
];

$aArr['test'][] = 2;

var_dump($aArr);



exit;
